# _Aluraflix2  - Projeto

A Pen created on CodePen.io. Original URL: [https://codepen.io/Johnny-da-Silva/pen/WNPzNyZ](https://codepen.io/Johnny-da-Silva/pen/WNPzNyZ).

